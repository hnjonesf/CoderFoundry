Template.notFound.onRendered(function () {
    $('.splash').css('display', 'none')
});