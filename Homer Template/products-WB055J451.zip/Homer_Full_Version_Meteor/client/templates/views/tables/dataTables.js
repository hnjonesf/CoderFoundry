Template.dataTables.onRendered(function(){

    // Initialize dataTables plugin
    $('#example1').dataTable({
        iDisplayLength: 25
    });

});