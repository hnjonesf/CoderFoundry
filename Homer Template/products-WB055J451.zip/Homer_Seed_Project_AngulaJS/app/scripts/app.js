/**
 * HOMER - Responsive Admin Theme
 * Copyright 2015 Webapplayers.com
 *
 */
(function () {
    angular.module('homer', [
        'ui.router',                // Angular flexible routing
        'ui.bootstrap'             // AngularJS native directives for Bootstrap
    ])
})();

