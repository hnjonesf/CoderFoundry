Homer - Meteor version 2015
version: 1.7

Meteor.js is an open-source platform built on Node and MongoDB
See documentation of Meteor to learn more: http://docs.meteor.com/#/full/
Install Meteor: https://www.meteor.com/install
Be sure that you have all setup - create the Meteor project and run the sample application: https://www.meteor.com/try

HOMER first run - just cd into Homer Meteor project and run the application with:

meteor

This will grab the necessary packages, bundle all the css and js and start your application
Go to http://localhost:3000 to see live version