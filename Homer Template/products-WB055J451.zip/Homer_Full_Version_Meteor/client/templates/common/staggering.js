Template.staggering.onRendered(function(){

    // Initialize animate panel function
    $('.animate-panel').animatePanel();

});