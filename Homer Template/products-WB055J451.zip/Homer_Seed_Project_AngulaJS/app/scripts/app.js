/**
 * HOMER - Responsive Admin Theme
 * version 1.7
 *
 */
(function () {
    angular.module('homer', [
        'ui.router',                // Angular flexible routing
        'ui.bootstrap'             // AngularJS native directives for Bootstrap
    ])
})();

