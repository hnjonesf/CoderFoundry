Template.fooTable.onRendered(function(){

    // Initialize Example 1
    $('#example1').footable();

    // Initialize Example 2
    $('#example2').footable();

});